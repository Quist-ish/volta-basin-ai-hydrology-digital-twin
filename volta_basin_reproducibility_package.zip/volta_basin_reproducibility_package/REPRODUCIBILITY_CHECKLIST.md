# Reproducibility checklist for editor/reviewer

## Data provenance
- [ ] CHIRPS source, version, download date, and local file checksums recorded.
- [ ] ERA5 variables, CDS query, date range, and aggregation rules recorded.
- [ ] G-RUN ENSEMBLE DOI, file name, temporal resolution, and period recorded.
- [ ] HydroSHEDS/SRTM source and preprocessing rules recorded.
- [ ] HWSD v2.0 source and aggregation rules recorded.
- [ ] Landsat-derived land-cover/vegetation processing documented.
- [ ] DAHITI station ID 97 and retrieval date recorded.
- [ ] UNOSAT FL20231018GHA source and retrieval date recorded.

## Benchmark safeguards
- [ ] G-RUN is described as a reanalysis benchmark, not observed gauge discharge.
- [ ] Monthly G-RUN runoff is not treated as direct daily discharge.
- [ ] Runoff-to-discharge conversion is documented.
- [ ] Benchmark-based learning/evaluation is restricted to matched G-RUN periods.
- [ ] 2020–2024 outputs are labelled model-only unless matched benchmark data are available.

## Machine-learning safeguards
- [ ] Chronological train/validation/test split used.
- [ ] Training: 1974–2004.
- [ ] Validation: 2005–2009.
- [ ] Testing: 2010–2019.
- [ ] No random cross-validation.
- [ ] Predictor standardization uses training statistics only.
- [ ] G-RUN benchmark discharge is excluded as predictor.
- [ ] Future benchmark information is excluded from predictors.

## Flood diagnostic safeguards
- [ ] Flood-state threshold is derived from G-RUN benchmark AMJJASO Q95.
- [ ] Same benchmark-derived threshold is used for model flood states.
- [ ] Flood-state calculations are restricted to valid basin-mask cells.
- [ ] Derived areas cannot exceed basin area.
- [ ] Flood-state maps are not described as observed inundation maps.

## External references
- [ ] DAHITI used only as contextual lake-level reference.
- [ ] UNOSAT used only as contextual flood-extent reference.
- [ ] No quantitative validation claims are made using DAHITI or UNOSAT.

## Code and outputs
- [ ] Configuration files uploaded.
- [ ] Figure-generation scripts uploaded.
- [ ] Model settings uploaded.
- [ ] Prediction outputs uploaded where redistribution is allowed.
- [ ] Derived diagnostics uploaded.
- [ ] Zenodo DOI and GitHub URL included in Data Availability.
