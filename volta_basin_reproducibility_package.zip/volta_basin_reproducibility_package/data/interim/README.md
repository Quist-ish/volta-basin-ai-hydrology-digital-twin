# data/interim

Placeholder directory for reproducibility package.

Do not commit restricted third-party raw data unless redistribution is allowed by the original provider.
Record file checksums and source metadata when adding data or outputs.
