# Metadata directory

This directory contains metadata for repository citation, Zenodo deposition, CodeMeta indexing, and dataset provenance.

Files:
- `data_sources_manifest.csv`: dataset source, access, role, and redistribution status.
- `zenodo.json`: metadata template for Zenodo deposition.
- `codemeta.json`: software metadata.
- `CITATION.cff`: repository citation file.
