# Volta Basin Benchmark-Relative Residual-Correction Framework

This repository supports the manuscript:

**Benchmark-relative two-stage residual correction combining WRF-Hydro, LSTM, and XGBoost for wet-season discharge and flood diagnostics in the regulated Volta River Basin, 1974–2024**

The repository is designed for reproducibility review by editors and reviewers. It contains configuration files, scripts, metadata templates, and workflow documentation for reproducing the benchmark-relative modelling framework.

## Core interpretation

G-RUN ENSEMBLE is used as a **reanalysis benchmark**, not as direct observed gauge discharge. All discharge metrics are therefore interpreted as benchmark-relative agreement, not independent hydrological validation.

WRF-Hydro simulations may cover 1974–2024. However, residual learning, benchmark-relative model evaluation, and G-RUN-derived diagnostics must be restricted to periods with matched G-RUN benchmark data, principally 1974–2019. Outputs beyond the G-RUN benchmark period are model-only simulations and must not be reported as benchmark-validated skill.

DAHITI Lake Volta water-level data and UNOSAT Sentinel-1 flood products are independent contextual references only. They are not used for training, tuning, calibration, discharge validation, or inundation validation.

## Repository structure

```text
config/                 YAML configuration files for data, models, evaluation, and diagnostics
metadata/               Zenodo, CodeMeta, citation, and dataset manifest files
scripts/                Reproducible workflow scripts and workflow notes
data/raw/               User-created links/symlinks to downloaded public datasets
data/interim/           Harmonized intermediate files
data/processed/         Processed model-ready inputs and benchmark products
wrfhydro/               WRF-Hydro domain, run, and configuration placeholders
models/lstm/            Trained LSTM model outputs and settings
models/xgboost/         Trained XGBoost model outputs and settings
outputs/                Predictions, metrics, and derived diagnostics
figures/                Figure-generation outputs
notebooks/              Optional notebooks for inspection only
```

## Reproducibility workflow

1. Download public datasets from their official providers or link existing local copies.
2. Harmonize all forcing and static datasets to the 0.05-degree CHIRPS target grid.
3. Prepare WRF-Hydro static inputs and forcing files.
4. Run standalone WRF-Hydro.
5. Convert G-RUN ENSEMBLE runoff to benchmark discharge by drainage-consistent area accumulation.
6. Build predictors using only available forcing, land-surface variables, WRF-Hydro discharge, and lagged predictors.
7. Train the first-stage LSTM on the residual `r1(t) = Qb(t) - QWRF(t)`.
8. Train the second-stage XGBoost model on `r2(t) = Qb(t) - Q_LSTM-H(t)`.
9. Evaluate only chronologically held-out benchmark-matched periods.
10. Generate discharge metrics, threshold-derived flood-state diagnostics, pattern-agreement figures, and tables.

## Editor concern safeguards

This package explicitly addresses the main editorial concerns:

- G-RUN is monthly runoff and is not treated as direct daily gauge discharge.
- G-RUN gridded runoff is converted to benchmark discharge using drainage-consistent area accumulation.
- Benchmark evaluation is restricted to matched G-RUN periods.
- No random cross-validation or temporal mixing is used.
- G-RUN benchmark discharge is not used as a predictor.
- DAHITI and UNOSAT are contextual references only.
- Flood-state diagnostics are threshold-derived and constrained to valid basin-mask cells.
- Flood-state diagnostics are not described as observed inundation validation.

## DOI and development repository

Zenodo archive: https://doi.org/10.5281/zenodo.20547379  
Development repository: https://github.com/Quist-ish/volta-basin-flood-dynamics-1974-2024
