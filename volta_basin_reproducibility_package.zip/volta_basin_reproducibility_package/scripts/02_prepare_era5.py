"""
Prepare ERA5 atmospheric variables.

Operations:
- Load ERA5 hourly fields.
- Resample from native grid to 0.05-degree CHIRPS grid.
- Bilinear interpolation for state variables.
- Area-weighted remapping for accumulated or flux variables.
- Aggregate hourly values to daily values.

Outputs:
- data/interim/era5_daily_0p05_{year}.nc
"""
from pathlib import Path

def main():
    Path("data/interim").mkdir(parents=True, exist_ok=True)
    print("Implement ERA5 preprocessing here.")

if __name__ == "__main__":
    main()
