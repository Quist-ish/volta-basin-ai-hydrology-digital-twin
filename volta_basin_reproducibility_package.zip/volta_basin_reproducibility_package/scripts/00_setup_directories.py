from pathlib import Path

directories = [
    "data/raw", "data/interim", "data/processed",
    "outputs/predictions", "outputs/metrics", "outputs/flood_diagnostics",
    "figures", "models/lstm", "models/xgboost", "wrfhydro/domain", "wrfhydro/run"
]

for d in directories:
    Path(d).mkdir(parents=True, exist_ok=True)

print("Directory structure created.")
