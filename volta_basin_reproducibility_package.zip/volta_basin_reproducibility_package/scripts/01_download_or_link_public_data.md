# Download or link public data

Raw third-party datasets should be downloaded directly from their public providers. This repository should not redistribute restricted raw data.

Expected local layout:

```text
data/raw/chirps/
data/raw/era5/
data/raw/grun_ensemble/
data/raw/hydrosheds/
data/raw/hwsd/
data/raw/landsat/
data/raw/dahiti/
data/raw/unosat/
```

After downloading, either place files in these folders or create symbolic links to your local data archive.

Critical checks:
- Confirm G-RUN temporal resolution and period before using it for residual learning.
- If only monthly G-RUN runoff is available, do not claim daily residual learning from monthly data.
- Any daily benchmark file must be documented in `metadata/data_sources_manifest.csv`.
