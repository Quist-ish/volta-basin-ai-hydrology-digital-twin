"""
Train first-stage LSTM residual model.

Target:
    r1(t) = Qb(t) - QWRF(t)

Leakage controls:
- Use chronological split only.
- Standardize predictors using training-period statistics only.
- Do not include Qb(t) or future benchmark information as predictors.
"""
def main():
    print("Load predictors, construct 30-day sequences, train LSTM, and save predictions/settings.")
    print("Expected split: train 1974-2004; validation 2005-2009; test 2010-2019.")

if __name__ == "__main__":
    main()
