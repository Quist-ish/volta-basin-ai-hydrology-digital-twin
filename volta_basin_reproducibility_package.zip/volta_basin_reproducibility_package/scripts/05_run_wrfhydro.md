# Run WRF-Hydro

Use the standalone WRF-Hydro configuration described in `config/wrfhydro_config.yaml`.

Required outputs:
- Daily routed discharge for Evaluation Location 1
- Daily routed discharge for Evaluation Location 2
- Optional gridded/routed discharge output for flood-state diagnostics

Important:
- Reservoir operations at Lake Volta and Akosombo-Kpong are not explicitly represented.
- Downstream residuals may include regulation effects.
- WRF-Hydro outputs for 2020–2024 are model-only unless matched benchmark data are available.
