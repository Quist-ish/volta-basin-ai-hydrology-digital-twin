"""
Calculate threshold-derived flood-state diagnostics.

Flood threshold:
    Q95,b,i(AMJJASO)

Benchmark flood state:
    Fb,i(t) = 1 if Qb,i(t) >= Q95,b,i else 0

Simulated flood state:
    Fs,i(t) = 1 if Qs,i(t) >= Q95,b,i else 0

Spatial safeguards:
- Restrict to valid basin-mask cells.
- Restrict to drainage-network-aligned cells.
- Derived flood-state area must not exceed physical basin area.
"""
import numpy as np

def flood_state(q, threshold):
    return (q >= threshold).astype(int)

def flood_area(F, cell_area):
    return np.sum(F * cell_area)

def disagreement(Fs, Fb):
    return np.mean(np.abs(Fs - Fb))

def main():
    print("Calculate flood-state area, bias, RMSE, frequency, and cell-wise disagreement.")

if __name__ == "__main__":
    main()
