"""
Monthly pattern agreement with G-RUN monthly runoff.

Steps:
- Aggregate daily two-stage corrected discharge to monthly values.
- Standardize modelled discharge and G-RUN monthly runoff to z-scores.
- Compare standardized anomalies at Senchi, Boromo, and Wayen.
- Report R2 and RMSE only as pattern agreement, not validation.
"""
def main():
    print("Compute standardized monthly pattern agreement for Senchi, Boromo, and Wayen.")

if __name__ == "__main__":
    main()
