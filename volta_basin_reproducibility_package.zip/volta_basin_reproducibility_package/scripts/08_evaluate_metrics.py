"""
Evaluate benchmark-relative discharge metrics.

Metrics:
- RMSE
- NSE
- R2
- KGE

Interpretation:
- Metrics measure agreement with G-RUN-derived benchmark.
- Metrics are not independent gauge validation.
"""
import numpy as np

def rmse(qs, qb):
    return float(np.sqrt(np.mean((qs - qb) ** 2)))

def nse(qs, qb):
    return float(1 - np.sum((qs - qb) ** 2) / np.sum((qb - np.mean(qb)) ** 2))

def r2(qs, qb):
    return float(np.corrcoef(qs, qb)[0, 1] ** 2)

def kge(qs, qb):
    r = np.corrcoef(qs, qb)[0, 1]
    alpha = np.std(qs) / np.std(qb)
    beta = np.mean(qs) / np.mean(qb)
    return float(1 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))

def main():
    print("Load benchmark and simulation outputs, restrict to benchmark-matched test years, calculate metrics.")

if __name__ == "__main__":
    main()
