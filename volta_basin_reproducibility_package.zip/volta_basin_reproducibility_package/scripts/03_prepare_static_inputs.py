"""
Prepare static terrain, drainage, soil, and land-cover inputs.

Inputs:
- HydroSHEDS/SRTM terrain and drainage data
- HWSD v2.0 soil data
- Landsat-derived land-cover and vegetation layers

Outputs:
- wrfhydro/domain/
- data/processed/static_predictors_0p05.nc

Critical safeguards:
- Keep basin mask.
- Keep drainage-network-aligned cells.
- Store cell areas for runoff-to-discharge conversion and flood-state area diagnostics.
"""
from pathlib import Path

def main():
    Path("wrfhydro/domain").mkdir(parents=True, exist_ok=True)
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    print("Implement static input processing here.")

if __name__ == "__main__":
    main()
