"""
Prepare G-RUN ENSEMBLE benchmark.

Critical interpretation:
- G-RUN is gridded runoff, not observed point discharge.
- Monthly G-RUN runoff must not be treated as direct daily discharge.
- For discharge comparison, runoff depth must be accumulated over upstream contributing area and converted to volumetric flow.

Conceptual conversion:
    Q_b(t) = sum_i [ runoff_i(t) * area_i ] / seconds_per_time_step

where runoff_i(t) is converted from mm/time-step to m/time-step and area_i is in m2.

Outputs:
- data/processed/grun_benchmark_discharge_locations.csv
- data/processed/grun_monthly_pattern_locations.csv
"""
from pathlib import Path

def runoff_to_discharge(runoff_mm, cell_area_m2, seconds_per_step):
    runoff_m = runoff_mm / 1000.0
    volume_m3 = runoff_m * cell_area_m2
    return volume_m3.sum() / seconds_per_step

def main():
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    print("Implement drainage-consistent G-RUN runoff-to-discharge conversion here.")

if __name__ == "__main__":
    main()
