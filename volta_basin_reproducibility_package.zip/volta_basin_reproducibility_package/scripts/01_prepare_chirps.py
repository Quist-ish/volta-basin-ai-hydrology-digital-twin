"""
Prepare CHIRPS v2.0 daily precipitation on the 0.05-degree target grid.

Inputs:
- data/raw/chirps/*.nc or *.tif

Outputs:
- data/interim/chirps_daily_0p05_{year}.nc

Notes:
- CHIRPS grid is used as the target grid for harmonization.
- Missing short gaps may be filled according to the manuscript rule.
"""
from pathlib import Path

def main():
    Path("data/interim").mkdir(parents=True, exist_ok=True)
    print("Implement CHIRPS preprocessing here: clipping, calendar checks, basin mask, and daily export.")

if __name__ == "__main__":
    main()
