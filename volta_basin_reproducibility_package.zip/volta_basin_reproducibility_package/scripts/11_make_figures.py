"""
Generate figures from processed outputs.

Every figure caption should state:
- G-RUN is a benchmark, not observed discharge.
- Flood-state maps are threshold-derived diagnostics, not observed inundation.
- DAHITI and UNOSAT are contextual references only.
"""
def main():
    print("Generate manuscript and supplementary figures from outputs.")

if __name__ == "__main__":
    main()
