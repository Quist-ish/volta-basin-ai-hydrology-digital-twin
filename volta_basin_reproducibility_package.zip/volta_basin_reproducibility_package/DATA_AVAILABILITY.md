# Data Availability and Redistribution Notice

The study uses public third-party datasets. Raw third-party datasets are not redistributed in this repository unless their licences explicitly allow redistribution. Instead, this repository provides dataset metadata, processing scripts, configuration files, and links to the original providers.

## Public source datasets

- CHIRPS v2.0 precipitation: Climate Hazards Center, UC Santa Barbara.
- ERA5 atmospheric reanalysis: Copernicus Climate Data Store / ECMWF.
- G-RUN ENSEMBLE runoff reanalysis: Figshare and associated publication.
- DAHITI Lake Volta water-level data, station ID 97: Database for Hydrological Time Series of Inland Waters.
- HydroSHEDS/SRTM terrain and drainage data: HydroSHEDS / WWF / USGS-derived hydrography.
- HWSD v2.0 soil data: FAO/IIASA.
- UNOSAT Sentinel-1 flood product: Ghana flood event, product code FL20231018GHA.

## Critical use constraints

- G-RUN ENSEMBLE is used as a reanalysis benchmark, not as direct observed discharge.
- G-RUN monthly runoff is not temporally disaggregated into daily discharge.
- Daily benchmark discharge, where used, must come from an available daily benchmark file or clearly documented benchmark processing. If only monthly G-RUN is available, daily residual learning must not be claimed.
- For the revised manuscript, benchmark-relative learning and evaluation are restricted to benchmark-matched years, principally 1974–2019.
- DAHITI and UNOSAT are retained as contextual references and are not used for model validation.
